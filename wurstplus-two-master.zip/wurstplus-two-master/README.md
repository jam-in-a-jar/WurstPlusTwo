# WurstPlusTwo
#### (for real this time)

made public for reasons below, updates will be pushed straight to this repo, if you'd like to help feel free to make a pull request :) <br>
also please note im not a professional programmer, i only did this for fun, so code here gets rather messy at times, over the next few weeks/months/whatever im going to attempt to clean it up and rewrite any remaining pasted code (mainly the GUI) <br>
if you want a specific hack made either ask or make it yourself ;) <br>
join the discord here : nvm discord got nuked

### how to use
DOWNLOAD THE JAR FROM THE RELEASES TAB ON THE RIGHT OF YOUR SCREEN <br>
'r-shift' is the default key for the gui and '.' is the default prefix, both can be changed either with commands or in the config file 

<details>
  <summary>Commands</summary> <br>
  Alert - toggles on & off alert message for given hack <br>
  Bind - binds a key to given hack <br>
  Config - changes the config folder being used (useful for different servers) <br>
  Drawn - toggles hack being drawn on the arraylist <br>
  Enemy - makes tab name red <br>
  EzMessage - changes the ezmessage to given string if custom mode in enabled <br>
  Friend - make tab name orange and certain modules wont target player <br>
  Help - lists commands <br>
  Prefix - changes prefix <br>
  Settings - to manualy save/load settings <br>
  Toggle - to manualy toggle hacks <br>
</details>

<details>
  <summary>Notable Hacks</summary> <br>
  Bed Aura - auto places and breaks beds on people (useful for endcrystal.me) <br>
  Auto Crystal - very good and <i>simple</i> to config, still needs work doing to though <br>
  Fucked Detector - highlights people who are in a bad hole/spot <br>
  Web Fill - holefill but for webs <br>
  Entity Mine - mine through entities <br><br>
  Everything else is fairly self explanatory <br>
</details>

### why
> Chad threatened to leak (apprently) and i don't really want ginger, or anyone else, to make any money of it (again)
> i also want to work on stuff with other people, and keep a paste private is cringeeeee

### what (exactly)
> the codebase is a mix of a base i wrote & a very early version of bope, over time i've learnt a lot and rewrote a lot of the pasted bope code but some still remains, especially the gui and the turok framework (for those wondering the 'leaked' version was just the bope code with a few modules and commands thrown in to make it look convincing)

### creds
> Rina (Turok) for the framework & bope [https://github.com/SirRina & https://discord.gg/teMyX8] <br>
> Salhack & phobos for misc stuff [https://github.com/ionar2/salhack] <br>
> tabbott for trying his best in the early stages of development <3

